using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public float smooth = 6f;
    public Vector2 offset = new Vector2(2f, 1.5f);
    public float minX = 0f, maxX = 100f, minY = 5.5f, maxY = 9f;

    void LateUpdate()
    {
        if (target == null) return;
        var cam = GetComponent<Camera>();
        float halfW = cam.orthographicSize * cam.aspect;
        Vector3 want = new Vector3(target.position.x + offset.x, target.position.y + offset.y, transform.position.z);
        want.x = Mathf.Clamp(want.x, minX + halfW, Mathf.Max(minX + halfW, maxX - halfW));
        want.y = Mathf.Clamp(want.y, minY, maxY);
        transform.position = Vector3.Lerp(transform.position, want, 1f - Mathf.Exp(-smooth * Time.deltaTime));
    }

    public void SnapToTarget()
    {
        if (target == null) return;
        var cam = GetComponent<Camera>();
        float halfW = cam.orthographicSize * cam.aspect;
        Vector3 p = new Vector3(target.position.x + offset.x, target.position.y + offset.y, transform.position.z);
        p.x = Mathf.Clamp(p.x, minX + halfW, Mathf.Max(minX + halfW, maxX - halfW));
        p.y = Mathf.Clamp(p.y, minY, maxY);
        transform.position = p;
    }
}
