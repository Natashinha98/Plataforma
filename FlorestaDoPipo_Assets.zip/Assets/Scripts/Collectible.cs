using UnityEngine;

// Itens: Maçã (obrigatória para vencer), Moeda (pontos) e Coração (vida extra).
public class Collectible : MonoBehaviour
{
    public enum Kind { Maca, Moeda, Coracao }
    public Kind kind = Kind.Moeda;
    public float bobHeight = 0.12f;
    public float bobSpeed = 3f;
    public GameObject sparklePrefab;

    Vector3 start;
    float phase;
    bool taken;

    void Awake()
    {
        start = transform.position;
        phase = Random.value * 6.28f;
    }

    void Update()
    {
        transform.position = start + Vector3.up * Mathf.Sin(Time.time * bobSpeed + phase) * bobHeight;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (taken) return;
        var player = other.GetComponent<PlayerController>();
        if (player == null || player.IsDead) return;
        taken = true;

        var level = FindFirstObjectByType<LevelManager>();
        string text = "";
        switch (kind)
        {
            case Kind.Maca:
                GameState.Score += 100; GameState.ApplesTotal++; text = "+100";
                break;
            case Kind.Moeda:
                GameState.Score += 10; text = "+10";
                break;
            case Kind.Coracao:
                if (GameState.Lives < GameState.MaxLives) { GameState.Lives++; text = "+1 vida"; }
                else { GameState.Score += 50; text = "+50"; }
                break;
        }
        if (sparklePrefab != null) Instantiate(sparklePrefab, transform.position, Quaternion.identity);
        if (level != null)
        {
            level.ShowPopup(text, transform.position);
            if (kind == Kind.Maca) level.OnAppleCollected();
        }
        Destroy(gameObject);
    }
}
