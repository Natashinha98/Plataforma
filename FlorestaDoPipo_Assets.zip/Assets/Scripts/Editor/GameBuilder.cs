using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Tilemaps;

// Menu "Pipo > Gerar Jogo": monta tiles, prefabs e as 4 cenas (Menu, Fase1, Fase2, Fim).
public static class GameBuilder
{
    public const string SpriteDir = "Assets/Resources/Sprites/";
    const int PPU = 16;

    static Material spriteMat;
    static Dictionary<string, TileBase> tiles;
    static GameObject poofPrefab, sparklePrefab, playerPrefab, slimePrefab, beePrefab, applePrefab, coinPrefab, heartPrefab;

    // ------------------------------------------------------------------ importação
    public static void ApplyImportSettings(TextureImporter ti, string path)
    {
        string file = Path.GetFileNameWithoutExtension(path);
        ti.textureType = TextureImporterType.Sprite;
        ti.spriteImportMode = SpriteImportMode.Single;
        ti.spritePixelsPerUnit = PPU;
        ti.filterMode = FilterMode.Point;
        ti.textureCompression = TextureImporterCompression.Uncompressed;
        ti.mipmapEnabled = false;
        ti.alphaIsTransparency = true;
        ti.isReadable = false;
        var st = new TextureImporterSettings();
        ti.ReadTextureSettings(st);
        st.spriteMeshType = SpriteMeshType.FullRect;
        st.spriteAlignment = (file.StartsWith("deco_") || file.StartsWith("bg_")) ? (int)SpriteAlignment.BottomCenter : (int)SpriteAlignment.Center;
        st.spriteGenerateFallbackPhysicsShape = true;
        st.wrapMode = file.StartsWith("bg_") ? TextureWrapMode.Repeat : TextureWrapMode.Clamp;
        ti.SetTextureSettings(st);
    }

    static void FixImports()
    {
        foreach (var guid in AssetDatabase.FindAssets("t:Texture2D", new[] { SpriteDir.TrimEnd('/') }))
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            var ti = AssetImporter.GetAtPath(path) as TextureImporter;
            if (ti == null) continue;
            ApplyImportSettings(ti, path);
            ti.SaveAndReimport();
        }
        AssetDatabase.Refresh();
    }

    static Sprite S(string name)
    {
        var s = AssetDatabase.LoadAssetAtPath<Sprite>(SpriteDir + name + ".png");
        if (s == null) Debug.LogError("Sprite não encontrado: " + name);
        return s;
    }
    static Sprite[] Frames(string prefix, params int[] idx)
    {
        var list = new Sprite[idx.Length];
        for (int i = 0; i < idx.Length; i++) list[i] = S(prefix + "_" + idx[i]);
        return list;
    }

    // ------------------------------------------------------------------ menu principal
    [MenuItem("Pipo/Gerar Jogo (todas as cenas)")]
    public static void BuildAll()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        EnsureFolder("Assets/Scenes"); EnsureFolder("Assets/Tiles"); EnsureFolder("Assets/Prefabs"); EnsureFolder("Assets/Physics");
        FixImports();
        FindMaterial();
        MakeTiles();
        MakePrefabs();

        BuildMenuScene();
        BuildLevelScene("Fase1", LevelMaps.Fase1, "Fase 1 - Bosque Ensolarado", "Fase2", false);
        BuildLevelScene("Fase2", LevelMaps.Fase2, "Fase 2 - Floresta ao Entardecer", "", true);
        BuildEndScene();

        EditorBuildSettings.scenes = new[]
        {
            new EditorBuildSettingsScene("Assets/Scenes/Menu.unity", true),
            new EditorBuildSettingsScene("Assets/Scenes/Fase1.unity", true),
            new EditorBuildSettingsScene("Assets/Scenes/Fase2.unity", true),
            new EditorBuildSettingsScene("Assets/Scenes/Fim.unity", true),
        };
        AssetDatabase.SaveAssets();
        EditorSceneManager.OpenScene("Assets/Scenes/Menu.unity");
        Debug.Log("<b>Pipo:</b> jogo gerado! Abra a cena Menu e aperte Play.");
    }

    static void EnsureFolder(string path)
    {
        if (AssetDatabase.IsValidFolder(path)) return;
        string parent = Path.GetDirectoryName(path).Replace('\\', '/');
        AssetDatabase.CreateFolder(parent, Path.GetFileName(path));
    }

    static void FindMaterial()
    {
        spriteMat = AssetDatabase.LoadAssetAtPath<Material>("Packages/com.unity.render-pipelines.universal/Runtime/Materials/Sprite-Unlit-Default.mat");
        if (spriteMat == null)
        {
            foreach (var guid in AssetDatabase.FindAssets("Sprite-Unlit-Default t:Material"))
            {
                spriteMat = AssetDatabase.LoadAssetAtPath<Material>(AssetDatabase.GUIDToAssetPath(guid));
                if (spriteMat != null) break;
            }
        }
    }

    static SpriteRenderer AddSR(GameObject go, Sprite sprite, int order)
    {
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = sprite;
        sr.sortingOrder = order;
        if (spriteMat != null) sr.sharedMaterial = spriteMat;
        return sr;
    }

    static SpriteAnimator.Clip Clip(string name, Sprite[] frames, float fps, bool loop = true)
    {
        return new SpriteAnimator.Clip { name = name, frames = frames, fps = fps, loop = loop };
    }

    // ------------------------------------------------------------------ tiles
    static void MakeTiles()
    {
        tiles = new Dictionary<string, TileBase>();
        string[] names = { "tile_fill", "tile_fill_l", "tile_fill_r", "tile_top", "tile_top_l", "tile_top_r", "tile_top_lr", "plank", "plank_l", "plank_r" };
        foreach (var n in names)
        {
            string path = "Assets/Tiles/" + n + ".asset";
            var t = AssetDatabase.LoadAssetAtPath<Tile>(path);
            if (t == null)
            {
                t = ScriptableObject.CreateInstance<Tile>();
                AssetDatabase.CreateAsset(t, path);
            }
            t.sprite = S(n);
            t.colliderType = Tile.ColliderType.Grid;
            EditorUtility.SetDirty(t);
            tiles[n] = t;
        }
        AssetDatabase.SaveAssets();
    }

    // ------------------------------------------------------------------ prefabs
    static GameObject SavePrefab(GameObject go, string name)
    {
        var p = PrefabUtility.SaveAsPrefabAsset(go, "Assets/Prefabs/" + name + ".prefab");
        Object.DestroyImmediate(go);
        return p;
    }

    static void MakePrefabs()
    {
        // Efeito de poeira
        var poof = new GameObject("Poeira");
        AddSR(poof, S("poof_0"), 20);
        poof.AddComponent<SpriteAnimator>().clips = new[] { Clip("poof", Frames("poof", 0, 1), 10, false) };
        poof.AddComponent<OneShotEffect>().lifetime = 0.25f;
        poofPrefab = SavePrefab(poof, "Poeira");

        // Brilho ao coletar
        var sparkle = new GameObject("Brilho");
        AddSR(sparkle, S("poof_1"), 20).color = new Color(1f, 0.95f, 0.4f);
        sparkle.AddComponent<SpriteAnimator>().clips = new[] { Clip("brilho", Frames("poof", 1, 0, 1), 14, false) };
        sparkle.AddComponent<OneShotEffect>().lifetime = 0.22f;
        sparklePrefab = SavePrefab(sparkle, "Brilho");

        // Material sem atrito (para não grudar nas paredes)
        var mat = AssetDatabase.LoadAssetAtPath<PhysicsMaterial2D>("Assets/Physics/SemAtrito.physicsMaterial2D");
        if (mat == null)
        {
            mat = new PhysicsMaterial2D("SemAtrito") { friction = 0f, bounciness = 0f };
            AssetDatabase.CreateAsset(mat, "Assets/Physics/SemAtrito.physicsMaterial2D");
        }

        // Jogador
        var p = new GameObject("Pipo");
        AddSR(p, S("player_idle_0"), 10);
        var rb = p.AddComponent<Rigidbody2D>();
        rb.gravityScale = 3.2f;
        rb.freezeRotation = true;
        rb.interpolation = RigidbodyInterpolation2D.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        rb.sharedMaterial = mat;
        var box = p.AddComponent<BoxCollider2D>();
        box.size = new Vector2(0.56f, 0.86f);
        box.offset = new Vector2(0f, -0.07f);
        box.edgeRadius = 0.02f;
        var an = p.AddComponent<SpriteAnimator>();
        an.clips = new[]
        {
            Clip("idle", Frames("player_idle", 0, 1), 3),
            Clip("run", Frames("player_run", 0, 1, 2, 3), 12),
            Clip("jump", Frames("player_jump", 0), 1),
            Clip("hurt", Frames("player_hurt", 0), 1),
        };
        an.startClip = "idle";
        p.AddComponent<PlayerController>().poofPrefab = poofPrefab;
        playerPrefab = SavePrefab(p, "Pipo");

        // Gosma
        var sl = new GameObject("Gosma");
        AddSR(sl, S("slime_0"), 6);
        var srb = sl.AddComponent<Rigidbody2D>(); srb.bodyType = RigidbodyType2D.Kinematic;
        var sbox = sl.AddComponent<BoxCollider2D>(); sbox.isTrigger = true; sbox.size = new Vector2(0.8f, 0.55f); sbox.offset = new Vector2(0f, -0.2f);
        var san = sl.AddComponent<SpriteAnimator>();
        san.clips = new[] { Clip("andar", Frames("slime", 0, 1, 0, 2), 6) };
        san.randomStart = true;
        var se = sl.AddComponent<Enemy>(); se.kind = Enemy.Kind.Gosma; se.speed = 1.5f; se.poofPrefab = poofPrefab;
        slimePrefab = SavePrefab(sl, "Gosma");

        // Besouro voador
        var be = new GameObject("Besouro");
        AddSR(be, S("bee_0"), 6);
        var brb = be.AddComponent<Rigidbody2D>(); brb.bodyType = RigidbodyType2D.Kinematic;
        var bbox = be.AddComponent<BoxCollider2D>(); bbox.isTrigger = true; bbox.size = new Vector2(0.8f, 0.55f); bbox.offset = new Vector2(0f, 0.1f);
        var ban = be.AddComponent<SpriteAnimator>();
        ban.clips = new[] { Clip("voar", Frames("bee", 0, 1), 14) };
        ban.randomStart = true;
        var bee = be.AddComponent<Enemy>(); bee.kind = Enemy.Kind.Besouro; bee.speed = 2f; bee.waveHeight = 0.5f; bee.poofPrefab = poofPrefab;
        beePrefab = SavePrefab(be, "Besouro");

        applePrefab = MakeItem("Maca", Collectible.Kind.Maca, Frames("apple", 0, 0, 0, 1), 6);
        coinPrefab = MakeItem("Moeda", Collectible.Kind.Moeda, Frames("coin", 0, 1, 2, 3), 10);
        heartPrefab = MakeItem("Coracao", Collectible.Kind.Coracao, Frames("heart", 0, 1), 4);
    }

    static GameObject MakeItem(string name, Collectible.Kind kind, Sprite[] frames, float fps)
    {
        var go = new GameObject(name);
        AddSR(go, frames[0], 5);
        var col = go.AddComponent<CircleCollider2D>(); col.isTrigger = true; col.radius = 0.38f;
        var an = go.AddComponent<SpriteAnimator>();
        an.clips = new[] { Clip("brilhar", frames, fps) };
        an.randomStart = true;
        var c = go.AddComponent<Collectible>(); c.kind = kind; c.sparklePrefab = sparklePrefab;
        return SavePrefab(go, name);
    }

    static GameObject Spawn(GameObject prefab, Vector3 pos, Transform parent)
    {
        var go = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
        if (parent != null) go.transform.SetParent(parent, true);
        go.transform.position = pos;
        PrefabUtility.RecordPrefabInstancePropertyModifications(go.transform);
        return go;
    }

    // ------------------------------------------------------------------ peças comuns de cena
    static Camera MakeCamera(Color bg, Vector3 pos)
    {
        var go = new GameObject("Main Camera");
        go.tag = "MainCamera";
        var cam = go.AddComponent<Camera>();
        cam.orthographic = true;
        cam.orthographicSize = 6f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = bg;
        cam.nearClipPlane = 0.3f;
        cam.farClipPlane = 100f;
        go.transform.position = new Vector3(pos.x, pos.y, -10f);
        go.AddComponent<AudioListener>();
        var urpCam = System.Type.GetType("UnityEngine.Rendering.Universal.UniversalAdditionalCameraData, Unity.RenderPipelines.Universal.Runtime");
        if (urpCam != null) go.AddComponent(urpCam);
        return cam;
    }

    static void AddParallaxLayer(string name, Sprite sprite, float factor, float offsetY, int order, Color tint, Vector3 camPos)
    {
        var root = new GameObject("Fundo - " + name);
        root.transform.position = new Vector3(camPos.x, camPos.y + offsetY, 0f);
        float w = sprite.bounds.size.x;
        for (int i = -1; i <= 1; i++)
        {
            var c = new GameObject(name + " " + (i + 2));
            c.transform.SetParent(root.transform, false);
            c.transform.localPosition = new Vector3(i * w, 0f, 0f);
            AddSR(c, sprite, order).color = tint;
        }
        var px = root.AddComponent<Parallax>();
        px.factor = factor;
        px.width = w;
        px.offsetY = offsetY;
    }

    static void AddBackground(bool dusk, Vector3 camPos)
    {
        // Quanto maior o fator, mais "longe" a camada parece (anda menos).
        AddParallaxLayer("Nuvens", S("bg_clouds"), 0.9f, -6.5f, -100, dusk ? new Color(1f, 0.78f, 0.82f) : Color.white, camPos);
        AddParallaxLayer("Morros distantes", S(dusk ? "bg_hills_far_dusk" : "bg_hills_far"), 0.75f, -6.2f, -90, Color.white, camPos);
        AddParallaxLayer("Morros próximos", S(dusk ? "bg_hills_near_dusk" : "bg_hills_near"), 0.5f, -6.6f, -80, Color.white, camPos);
    }

    static readonly Dictionary<char, string> DecoSprites = new Dictionary<char, string>
    {
        { 'T', "deco_tree" }, { 'F', "deco_fence" }, { 'L', "deco_lamp" }, { 'R', "deco_rock" },
        { 'f', "deco_sunflower" }, { 'n', "deco_signpost" }, { 'k', "deco_chest" },
    };

    static Tilemap MakeTilemap(out GameObject gridGo)
    {
        gridGo = new GameObject("Grid");
        gridGo.AddComponent<Grid>();
        gridGo.transform.position = new Vector3(-0.5f, -0.5f, 0f); // centro de cada célula em coordenada inteira
        return AddTilemap(gridGo, "Chao (Tilemap)", false);
    }

    // Plataformas de madeira: dá para atravessar por baixo (Platform Effector 2D).
    static Tilemap AddTilemap(GameObject gridGo, string name, bool oneWay)
    {
        var tmGo = new GameObject(name);
        tmGo.transform.SetParent(gridGo.transform, false);
        var tm = tmGo.AddComponent<Tilemap>();
        var tr = tmGo.AddComponent<TilemapRenderer>();
        tr.sortingOrder = 0;
        if (spriteMat != null) tr.sharedMaterial = spriteMat;
        // A colisão é feita pelos BoxCollider2D gerados em BuildColliders (mais confiável que o Tilemap Collider nesta versão).
        return tm;
    }

    // ------------------------------------------------------------------ fases
    static void BuildLevelScene(string sceneName, string[] map, string title, string next, bool dusk)
    {
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        int H = map.Length, W = 0;
        foreach (var r in map) W = Mathf.Max(W, r.Length);
        char At(int c, int r) => (r < 0 || r >= H || c < 0 || c >= map[r].Length) ? '.' : map[r][c];
        bool Solid(int c, int r) { char ch = At(c, r); return ch == '#' || ch == '='; }

        Vector3 startPos = new Vector3(2, 4, 0);
        for (int r = 0; r < H; r++) for (int c = 0; c < map[r].Length; c++) if (map[r][c] == 'P') startPos = new Vector3(c, H - 1 - r, 0);

        var cam = MakeCamera(dusk ? new Color(0.55f, 0.5f, 0.78f) : new Color(0.533f, 0.761f, 0.965f), startPos + new Vector3(6, 4, 0));
        AddBackground(dusk, cam.transform.position);

        var tm = MakeTilemap(out var gridGo);
        var planks = AddTilemap(gridGo, "Plataformas (Tilemap)", true);
        var items = new GameObject("Itens").transform;
        var enemies = new GameObject("Inimigos").transform;
        var decor = new GameObject("Decoracao").transform;

        for (int r = 0; r < H; r++)
        {
            for (int c = 0; c < map[r].Length; c++)
            {
                char ch = map[r][c];
                int y = H - 1 - r;
                var cell = new Vector3Int(c, y, 0);
                var pos = new Vector3(c, y, 0);
                if (ch == '#')
                {
                    bool top = At(c, r - 1) != '#';
                    bool l = At(c - 1, r) != '#';
                    bool rr = At(c + 1, r) != '#';
                    string t = top ? (l && rr ? "tile_top_lr" : l ? "tile_top_l" : rr ? "tile_top_r" : "tile_top")
                                   : (l ? "tile_fill_l" : rr ? "tile_fill_r" : "tile_fill");
                    tm.SetTile(cell, tiles[t]);
                }
                else if (ch == '=')
                {
                    bool l = At(c - 1, r) != '=';
                    bool rr = At(c + 1, r) != '=';
                    planks.SetTile(cell, tiles[l ? "plank_l" : rr ? "plank_r" : "plank"]);
                }
                else if (ch == 'A') Spawn(applePrefab, pos, items);
                else if (ch == 'C') Spawn(coinPrefab, pos, items);
                else if (ch == 'H') Spawn(heartPrefab, pos, items);
                else if (ch == 'S')
                {
                    var e = Spawn(slimePrefab, pos, enemies).GetComponent<Enemy>();
                    int left = 0, right = 0;
                    while (left < 5 && !Solid(c - left - 1, r) && Solid(c - left - 1, r + 1)) left++;
                    while (right < 5 && !Solid(c + right + 1, r) && Solid(c + right + 1, r + 1)) right++;
                    e.minX = c - left; e.maxX = c + right;
                    PrefabUtility.RecordPrefabInstancePropertyModifications(e);
                }
                else if (ch == 'B')
                {
                    var e = Spawn(beePrefab, pos, enemies).GetComponent<Enemy>();
                    e.minX = c - 3; e.maxX = c + 3;
                    PrefabUtility.RecordPrefabInstancePropertyModifications(e);
                }
                else if (DecoSprites.TryGetValue(ch, out var deco))
                {
                    var d = new GameObject(deco.Replace("deco_", ""));
                    d.transform.SetParent(decor, false);
                    d.transform.position = new Vector3(c, y - 0.5f, 0);
                    AddSR(d, S(deco), ch == 'T' ? -12 : -10);
                }
            }
        }
        tm.CompressBounds();
        planks.CompressBounds();
        BuildColliders(map, H);

        // Paredes invisíveis nas bordas da fase
        MakeWall("Parede esquerda", new Vector3(-1f, H / 2f, 0), new Vector2(1f, H * 3));
        MakeWall("Parede direita", new Vector3(W, H / 2f, 0), new Vector2(1f, H * 3));

        var player = Spawn(playerPrefab, startPos, null);

        var follow = cam.gameObject.AddComponent<CameraFollow>();
        follow.target = player.transform;
        follow.minX = -0.5f; follow.maxX = W - 0.5f;
        follow.minY = 5.5f; follow.maxY = 8f;

        var lm = new GameObject("LevelManager").AddComponent<LevelManager>();
        lm.levelTitle = title;
        lm.nextScene = next;
        lm.killY = -3f;
        lm.heartIcon = S("heart_0"); lm.appleIcon = S("apple_0"); lm.coinIcon = S("coin_0");

        EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(), "Assets/Scenes/" + sceneName + ".unity");
    }

    // Colisores do cenário: junta os blocos vizinhos em retângulos (BoxCollider2D).
    // Chão (#) é sólido; plataformas de madeira (=) são "one-way" (atravessa por baixo).
    static void BuildColliders(string[] map, int H)
    {
        var root = new GameObject("Colisores do cenario").transform;
        var open = new Dictionary<(int, int), (int top, int bottom)>();
        var done = new List<(int c0, int c1, int top, int bottom)>();
        for (int r = 0; r <= H; r++)
        {
            var runs = new HashSet<(int, int)>();
            if (r < H)
            {
                string row = map[r];
                for (int c = 0; c < row.Length; c++)
                {
                    if (row[c] != '#') continue;
                    int c0 = c;
                    while (c + 1 < row.Length && row[c + 1] == '#') c++;
                    runs.Add((c0, c));
                }
            }
            foreach (var key in new List<(int, int)>(open.Keys))
            {
                if (runs.Contains(key)) { var v = open[key]; open[key] = (v.top, r); runs.Remove(key); }
                else { var v = open[key]; done.Add((key.Item1, key.Item2, v.top, v.bottom)); open.Remove(key); }
            }
            foreach (var run in runs) open[run] = (r, r);
        }
        foreach (var d in done)
        {
            var go = new GameObject("Chao " + d.c0 + "-" + d.c1);
            go.transform.SetParent(root, false);
            float yTop = H - 1 - d.top + 0.5f, yBottom = H - 1 - d.bottom - 0.5f;
            go.transform.position = new Vector3((d.c0 + d.c1) / 2f, (yTop + yBottom) / 2f, 0);
            go.AddComponent<BoxCollider2D>().size = new Vector2(d.c1 - d.c0 + 1, yTop - yBottom);
        }
        for (int r = 0; r < H; r++)
        {
            string row = map[r];
            for (int c = 0; c < row.Length; c++)
            {
                if (row[c] != '=') continue;
                int c0 = c;
                while (c + 1 < row.Length && row[c + 1] == '=') c++;
                int y = H - 1 - r;
                var go = new GameObject("Plataforma " + c0 + "-" + c);
                go.transform.SetParent(root, false);
                go.transform.position = new Vector3((c0 + c) / 2f, y + 0.25f, 0);
                var box = go.AddComponent<BoxCollider2D>();
                box.size = new Vector2(c - c0 + 1, 0.5f);
                box.usedByEffector = true;
                var eff = go.AddComponent<PlatformEffector2D>();
                eff.useOneWay = true;
                eff.surfaceArc = 160f;
            }
        }
    }

    static void MakeWall(string name, Vector3 pos, Vector2 size)
    {
        var w = new GameObject(name);
        w.transform.position = pos;
        w.AddComponent<BoxCollider2D>().size = size;
    }

    // ------------------------------------------------------------------ cenário de menu / fim
    static void BuildShowcase(Camera cam, bool dusk)
    {
        AddBackground(dusk, cam.transform.position);
        var tm = MakeTilemap(out _);
        for (int c = -14; c <= 14; c++)
            for (int y = -6; y <= -4; y++)
            {
                bool top = y == -4;
                tm.SetTile(new Vector3Int(c, y, 0), tiles[top ? "tile_top" : "tile_fill"]);
            }
        var decor = new GameObject("Decoracao").transform;
        void D(string s, float x, int order = -10)
        {
            var d = new GameObject(s.Replace("deco_", ""));
            d.transform.SetParent(decor, false);
            d.transform.position = new Vector3(x, -3.5f, 0);
            AddSR(d, S(s), order);
        }
        D("deco_tree", -9.5f, -12); D("deco_fence", -5f); D("deco_sunflower", -2.5f); D("deco_lamp", 6f);
        D("deco_tree", 10f, -12); D("deco_rock", 3f); D("deco_signpost", -12f); D("deco_sunflower", 8.2f);
    }

    static void BuildMenuScene()
    {
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var cam = MakeCamera(new Color(0.533f, 0.761f, 0.965f), Vector3.zero);
        BuildShowcase(cam, false);

        var pipo = new GameObject("Pipo (enfeite)");
        pipo.transform.position = new Vector3(-7f, -3f, 0);
        AddSR(pipo, S("player_idle_0"), 10);
        pipo.AddComponent<SpriteAnimator>().clips = new[] { Clip("idle", Frames("player_idle", 0, 1), 3) };
        var slime = new GameObject("Gosma (enfeite)");
        slime.transform.position = new Vector3(4.5f, -3f, 0);
        AddSR(slime, S("slime_0"), 6).flipX = true;
        slime.AddComponent<SpriteAnimator>().clips = new[] { Clip("andar", Frames("slime", 0, 1, 0, 2), 6) };

        var ui = new GameObject("MenuUI").AddComponent<MenuUI>();
        ui.appleIcon = S("apple_0"); ui.coinIcon = S("coin_0"); ui.heartIcon = S("heart_0"); ui.slimeIcon = S("slime_0");
        EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(), "Assets/Scenes/Menu.unity");
    }

    static void BuildEndScene()
    {
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var cam = MakeCamera(new Color(0.55f, 0.5f, 0.78f), Vector3.zero);
        BuildShowcase(cam, true);
        var ui = new GameObject("EndUI").AddComponent<EndUI>();
        ui.winIcon = S("apple_0"); ui.loseIcon = S("player_hurt_0");
        EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(), "Assets/Scenes/Fim.unity");
    }
}
