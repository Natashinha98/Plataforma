using UnityEditor;
using UnityEngine;

// Configura automaticamente os PNGs da pasta de sprites (pixel art nítida, 16 px por unidade).
public class SpriteImportRules : AssetPostprocessor
{
    void OnPreprocessTexture()
    {
        if (!assetPath.StartsWith(GameBuilder.SpriteDir)) return;
        GameBuilder.ApplyImportSettings((TextureImporter)assetImporter, assetPath);
    }
}
