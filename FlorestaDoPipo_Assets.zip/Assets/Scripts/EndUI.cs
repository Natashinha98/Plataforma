using UnityEngine;
using UnityEngine.SceneManagement;

// Cena final: mostra vitória ou derrota e o botão de reiniciar.
public class EndUI : MonoBehaviour
{
    public Sprite winIcon, loseIcon;

    void Update()
    {
        if (GameInput.ConfirmPressed()) GameState.StartNewGame();
    }

    void OnGUI()
    {
        float s = UIKit.Scale;
        float w = 640 * s, h = 420 * s;
        Rect panel = new Rect((Screen.width - w) / 2f, (Screen.height - h) / 2f, w, h);
        UIKit.Panel(panel);

        bool won = GameState.Won;
        var title = UIKit.Label(64, won ? new Color(1f, 0.85f, 0.3f) : new Color(1f, 0.4f, 0.4f));
        UIKit.ShadowLabel(new Rect(panel.x, panel.y + 24 * s, w, 80 * s), won ? "VITÓRIA!" : "DERROTA", title);

        UIKit.DrawSprite(new Rect(panel.center.x - 40 * s, panel.y + 110 * s, 80 * s, 80 * s), won ? winIcon : loseIcon);

        var txt = UIKit.Label(24, Color.white, TextAnchor.MiddleCenter, false);
        string msg = won
            ? "O Pipo coletou todas as maçãs da floresta!"
            : "Os inimigos venceram desta vez... tente de novo!";
        GUI.Label(new Rect(panel.x + 20 * s, panel.y + 200 * s, w - 40 * s, 40 * s), msg, txt);
        GUI.Label(new Rect(panel.x, panel.y + 240 * s, w, 40 * s), $"<b>Pontuação: {GameState.Score}</b>   ·   Maçãs: {GameState.ApplesTotal}", txt);

        if (GUI.Button(new Rect(panel.center.x - 290 * s, panel.yMax - 90 * s, 280 * s, 60 * s), "REINICIAR", UIKit.Button(28)))
            GameState.StartNewGame();
        if (GUI.Button(new Rect(panel.center.x + 10 * s, panel.yMax - 90 * s, 280 * s, 60 * s), "MENU", UIKit.Button(28)))
        {
            GameState.ResetGame();
            SceneManager.LoadScene("Menu");
        }
    }
}
