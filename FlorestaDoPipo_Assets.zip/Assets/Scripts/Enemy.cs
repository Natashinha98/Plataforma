using UnityEngine;

// Inimigo que patrulha. Gosma anda no chão; besouro voa ondulando.
[RequireComponent(typeof(SpriteRenderer))]
public class Enemy : MonoBehaviour
{
    public enum Kind { Gosma, Besouro }
    public Kind kind = Kind.Gosma;
    public float speed = 1.6f;
    [Tooltip("Limite esquerdo e direito da patrulha (posição X no mundo).")]
    public float minX, maxX;
    public float waveHeight = 0.6f;
    public float waveSpeed = 3f;
    public GameObject poofPrefab;

    SpriteRenderer sr;
    int dir = -1;
    float baseY;
    public bool IsDead { get; private set; }

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        baseY = transform.position.y;
        if (minX == 0f && maxX == 0f) { minX = transform.position.x - 3f; maxX = transform.position.x + 3f; }
    }

    void Update()
    {
        if (IsDead) return;
        var p = transform.position;
        p.x += dir * speed * Time.deltaTime;
        if (p.x <= minX) { p.x = minX; dir = 1; }
        if (p.x >= maxX) { p.x = maxX; dir = -1; }
        if (kind == Kind.Besouro)
            p.y = baseY + Mathf.Sin(Time.time * waveSpeed) * waveHeight;
        transform.position = p;
        // Os sprites foram desenhados olhando para a esquerda (gosma é simétrica).
        sr.flipX = dir > 0;
    }

    public void Stomp()
    {
        if (IsDead) return;
        IsDead = true;
        if (poofPrefab != null) Instantiate(poofPrefab, transform.position, Quaternion.identity);
        Destroy(gameObject);
    }
}
