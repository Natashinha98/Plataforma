using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

// Lê o teclado/controle funcionando tanto com o Input System novo quanto com o antigo.
public static class GameInput
{
    public static float Horizontal()
    {
#if ENABLE_INPUT_SYSTEM
        float h = 0f;
        var k = Keyboard.current;
        if (k != null)
        {
            if (k.leftArrowKey.isPressed || k.aKey.isPressed) h -= 1f;
            if (k.rightArrowKey.isPressed || k.dKey.isPressed) h += 1f;
        }
        var g = Gamepad.current;
        if (g != null)
        {
            float gx = g.leftStick.x.ReadValue();
            if (Mathf.Abs(gx) > 0.3f) h = Mathf.Sign(gx);
            if (g.dpad.left.isPressed) h = -1f;
            if (g.dpad.right.isPressed) h = 1f;
        }
        return h;
#else
        return Input.GetAxisRaw("Horizontal");
#endif
    }

    public static bool JumpPressed()
    {
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        var g = Gamepad.current;
        return (k != null && (k.spaceKey.wasPressedThisFrame || k.wKey.wasPressedThisFrame || k.upArrowKey.wasPressedThisFrame))
            || (g != null && g.buttonSouth.wasPressedThisFrame);
#else
        return Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow);
#endif
    }

    public static bool JumpHeld()
    {
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        var g = Gamepad.current;
        return (k != null && (k.spaceKey.isPressed || k.wKey.isPressed || k.upArrowKey.isPressed))
            || (g != null && g.buttonSouth.isPressed);
#else
        return Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow);
#endif
    }

    public static bool ConfirmPressed()
    {
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        var g = Gamepad.current;
        return (k != null && (k.enterKey.wasPressedThisFrame || k.numpadEnterKey.wasPressedThisFrame))
            || (g != null && g.startButton.wasPressedThisFrame);
#else
        return Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter);
#endif
    }
}
