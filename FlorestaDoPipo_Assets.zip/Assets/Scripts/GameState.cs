using UnityEngine;
using UnityEngine.SceneManagement;

// Guarda os dados que passam de uma cena para outra (pontos, vidas, resultado).
public static class GameState
{
    public const int StartLives = 3;
    public const int MaxLives = 5;

    public static int Score;
    public static int Lives = StartLives;
    public static int ApplesTotal;      // maçãs coletadas no jogo todo
    public static bool Won;
    public static string LastLevel = "Fase1";

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    static void ResetOnPlay() { ResetGame(); }

    public static void ResetGame()
    {
        Score = 0;
        Lives = StartLives;
        ApplesTotal = 0;
        Won = false;
    }

    public static void StartNewGame()
    {
        ResetGame();
        SceneManager.LoadScene("Fase1");
    }

    public static void GoToEnd(bool won)
    {
        Won = won;
        SceneManager.LoadScene("Fim");
    }
}
