using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// Controla a fase: conta as maçãs, mostra o HUD, trata quedas e passa de fase.
public class LevelManager : MonoBehaviour
{
    public string levelTitle = "Fase 1 - Bosque Ensolarado";
    public string nextScene = "Fase2";   // vazio = última fase (vitória)
    public float killY = -3f;
    public Sprite heartIcon;
    public Sprite appleIcon;
    public Sprite coinIcon;

    PlayerController player;
    int applesInLevel;
    int applesCollected;
    float finishTime = -1f;
    float titleUntil;

    class Popup { public string text; public Vector3 pos; public float t; }
    readonly List<Popup> popups = new List<Popup>();

    public bool IsFinished => finishTime >= 0f;

    void Start()
    {
        player = FindFirstObjectByType<PlayerController>();
        foreach (var c in FindObjectsByType<Collectible>(FindObjectsSortMode.None))
            if (c.kind == Collectible.Kind.Maca) applesInLevel++;
        GameState.LastLevel = SceneManager.GetActiveScene().name;
        titleUntil = Time.time + 2.5f;
        var follow = Camera.main != null ? Camera.main.GetComponent<CameraFollow>() : null;
        if (follow != null) follow.SnapToTarget();
    }

    void Update()
    {
        if (player != null && !player.IsDead && player.transform.position.y < killY)
            player.FellInPit();

        if (IsFinished && Time.time - finishTime > 2.2f)
        {
            if (string.IsNullOrEmpty(nextScene)) GameState.GoToEnd(true);
            else SceneManager.LoadScene(nextScene);
            finishTime = float.MaxValue; // evita carregar duas vezes
        }

        for (int i = popups.Count - 1; i >= 0; i--)
        {
            popups[i].t += Time.deltaTime;
            if (popups[i].t > 0.9f) popups.RemoveAt(i);
        }
    }

    public void OnAppleCollected()
    {
        applesCollected++;
        if (applesCollected >= applesInLevel && !IsFinished)
            finishTime = Time.time;
    }

    public void ShowPopup(string text, Vector3 worldPos)
    {
        if (string.IsNullOrEmpty(text)) return;
        popups.Add(new Popup { text = text, pos = worldPos, t = 0f });
    }

    void OnGUI()
    {
        float s = UIKit.Scale;
        float pad = 16 * s;

        // Painel do HUD
        UIKit.Panel(new Rect(pad, pad, 300 * s, 118 * s));
        // Vidas
        for (int i = 0; i < Mathf.Max(GameState.Lives, 0); i++)
            UIKit.DrawSprite(new Rect(pad + 12 * s + i * 34 * s, pad + 10 * s, 30 * s, 30 * s), heartIcon);
        // Maçãs
        UIKit.DrawSprite(new Rect(pad + 12 * s, pad + 46 * s, 28 * s, 28 * s), appleIcon);
        var lbl = UIKit.Label(24, Color.white, TextAnchor.MiddleLeft);
        GUI.Label(new Rect(pad + 48 * s, pad + 44 * s, 240 * s, 32 * s), $"Maçãs: {applesCollected}/{applesInLevel}", lbl);
        // Pontos
        UIKit.DrawSprite(new Rect(pad + 14 * s, pad + 82 * s, 26 * s, 24 * s), coinIcon);
        GUI.Label(new Rect(pad + 48 * s, pad + 78 * s, 240 * s, 32 * s), $"Pontos: {GameState.Score}", lbl);

        // Nome da fase
        var titleStyle = UIKit.Label(20, new Color(1f, 1f, 1f, 0.9f), TextAnchor.UpperRight);
        UIKit.ShadowLabel(new Rect(Screen.width - 520 * s - pad, pad, 520 * s, 40 * s), levelTitle, titleStyle);

        // Título grande no começo da fase
        if (Time.time < titleUntil)
        {
            var big = UIKit.Label(54, Color.white);
            UIKit.ShadowLabel(new Rect(0, Screen.height * 0.28f, Screen.width, 80 * s), levelTitle, big);
            var sub = UIKit.Label(26, new Color(1f, 0.95f, 0.7f));
            UIKit.ShadowLabel(new Rect(0, Screen.height * 0.28f + 76 * s, Screen.width, 40 * s), $"Colete as {applesInLevel} maçãs!", sub);
        }

        // Fase concluída
        if (IsFinished)
        {
            var big = UIKit.Label(56, new Color(1f, 0.9f, 0.3f));
            string msg = string.IsNullOrEmpty(nextScene) ? "Todas as maçãs coletadas!" : "Fase concluída!";
            UIKit.ShadowLabel(new Rect(0, Screen.height * 0.35f, Screen.width, 90 * s), msg, big);
        }

        // Textos flutuantes (+10, +100...)
        var cam = Camera.main;
        if (cam != null)
        {
            var ps = UIKit.Label(22, new Color(1f, 0.95f, 0.5f));
            foreach (var p in popups)
            {
                Vector3 sp = cam.WorldToScreenPoint(p.pos + Vector3.up * (0.6f + p.t * 1.2f));
                var c = ps.normal.textColor; c.a = 1f - p.t / 0.9f; ps.normal.textColor = c;
                UIKit.ShadowLabel(new Rect(sp.x - 80 * s, Screen.height - sp.y - 16 * s, 160 * s, 32 * s), p.text, ps);
            }
        }
    }
}
