using UnityEngine;

// Tela inicial com as instruções de como jogar.
public class MenuUI : MonoBehaviour
{
    public Sprite appleIcon, coinIcon, heartIcon, slimeIcon;

    void Update()
    {
        if (GameInput.ConfirmPressed()) GameState.StartNewGame();
    }

    void OnGUI()
    {
        float s = UIKit.Scale;
        float w = 760 * s, h = 540 * s;
        Rect panel = new Rect((Screen.width - w) / 2f, (Screen.height - h) / 2f + 50 * s, w, h);

        var title = UIKit.Label(62, new Color(1f, 0.82f, 0.35f));
        UIKit.ShadowLabel(new Rect(0, panel.y - 90 * s, Screen.width, 80 * s), "Pipo e as Maçãs da Floresta", title);

        UIKit.Panel(panel);
        float x = panel.x + 36 * s, y = panel.y + 24 * s;
        var head = UIKit.Label(30, new Color(1f, 0.82f, 0.35f), TextAnchor.MiddleLeft);
        var txt = UIKit.Label(22, Color.white, TextAnchor.MiddleLeft, false);

        GUI.Label(new Rect(x, y, w, 40 * s), "COMO JOGAR", head); y += 50 * s;
        GUI.Label(new Rect(x, y, w - 70 * s, 34 * s), "<b>Setas</b> (esquerda/direita) ou <b>A</b> / <b>D</b>  -  andar", txt); y += 36 * s;
        GUI.Label(new Rect(x, y, w - 70 * s, 34 * s), "<b>Espaço</b>, <b>W</b> ou <b>seta para cima</b>  -  pular (segure para ir mais alto)", txt); y += 36 * s;
        GUI.Label(new Rect(x, y, w - 70 * s, 34 * s), "Pule <b>em cima</b> dos inimigos para derrotá-los", txt); y += 50 * s;

        GUI.Label(new Rect(x, y, w, 40 * s), "OBJETIVO", head); y += 50 * s;
        float icon = 32 * s;
        UIKit.DrawSprite(new Rect(x, y, icon, icon), appleIcon);
        GUI.Label(new Rect(x + 46 * s, y - 2 * s, w - 110 * s, 36 * s), "Colete <b>todas as maçãs</b> das 2 fases para vencer", txt); y += 42 * s;
        UIKit.DrawSprite(new Rect(x, y + 2 * s, icon, icon * 0.85f), coinIcon);
        GUI.Label(new Rect(x + 46 * s, y - 2 * s, w - 110 * s, 36 * s), "Moedas dão pontos extras", txt); y += 42 * s;
        UIKit.DrawSprite(new Rect(x, y, icon, icon), heartIcon);
        GUI.Label(new Rect(x + 46 * s, y - 2 * s, w - 110 * s, 36 * s), "Corações dão uma vida extra", txt); y += 42 * s;
        UIKit.DrawSprite(new Rect(x, y, icon, icon), slimeIcon);
        GUI.Label(new Rect(x + 46 * s, y - 2 * s, w - 110 * s, 36 * s), "Encostar nos inimigos tira uma vida. Sem vidas = derrota!", txt); y += 56 * s;

        if (GUI.Button(new Rect(panel.x + (w - 280 * s) / 2f, panel.yMax - 76 * s, 280 * s, 58 * s), "JOGAR  (Enter)", UIKit.Button(28)))
            GameState.StartNewGame();
    }
}
