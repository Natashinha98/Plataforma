using UnityEngine;

// Efeito que toca uma vez (poeira/brilho) e se destrói.
public class OneShotEffect : MonoBehaviour
{
    public float lifetime = 0.35f;
    void Start() { Destroy(gameObject, lifetime); }
}
