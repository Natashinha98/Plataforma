using UnityEngine;

// Camada de fundo com parallax. factor = 0 anda junto com o mundo; 1 fica parada com a câmera.
public class Parallax : MonoBehaviour
{
    [Range(0f, 1f)] public float factor = 0.5f;
    [Tooltip("Largura de uma cópia do sprite, em unidades (para repetir infinitamente).")]
    public float width = 20f;
    public float offsetY = 0f;

    Transform cam;
    float startX;

    void Start()
    {
        cam = Camera.main.transform;
        startX = transform.position.x - cam.position.x * factor;
    }

    void LateUpdate()
    {
        if (cam == null) return;
        float moved = cam.position.x * (1f - factor);   // quanto a câmera "andou" relativo à camada
        float dist = cam.position.x * factor;           // quanto a camada acompanha a câmera
        transform.position = new Vector3(startX + dist, cam.position.y + offsetY, transform.position.z);

        if (moved > startX + width) startX += width;
        else if (moved < startX - width) startX -= width;
    }
}
