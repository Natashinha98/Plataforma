using System.Collections;
using UnityEngine;

// Pipo, a raposa: anda, pula, pisa nos inimigos e coleta itens.
[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(BoxCollider2D))]
public class PlayerController : MonoBehaviour
{
    [Header("Movimento")]
    public float moveSpeed = 6.5f;
    public float acceleration = 60f;
    public float jumpVelocity = 15f;
    public float coyoteTime = 0.1f;
    public float jumpBuffer = 0.12f;

    [Header("Dano")]
    public float invulnerableTime = 1.5f;
    public Vector2 knockback = new Vector2(6f, 8f);
    public float stompBounce = 12f;

    [Header("Efeitos")]
    public GameObject poofPrefab;

    Rigidbody2D rb;
    BoxCollider2D box;
    SpriteRenderer sr;
    SpriteAnimator anim;
    LevelManager level;

    float lastGroundedTime = -10f;
    float lastJumpPressTime = -10f;
    float invulnerableUntil;
    float controlLockedUntil;
    bool grounded;
    bool dead;
    Vector3 spawnPoint;

    public bool IsDead => dead;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        box = GetComponent<BoxCollider2D>();
        sr = GetComponent<SpriteRenderer>();
        anim = GetComponent<SpriteAnimator>();
        spawnPoint = transform.position;
    }

    void Start()
    {
        level = FindFirstObjectByType<LevelManager>();
    }

    void Update()
    {
        if (dead || (level != null && level.IsFinished)) return;

        if (GameInput.JumpPressed()) lastJumpPressTime = Time.time;

        // Pulo com "coyote time" e "buffer" para o controle ficar mais gostoso.
        if (Time.time - lastJumpPressTime <= jumpBuffer && Time.time - lastGroundedTime <= coyoteTime)
        {
            var v = rb.linearVelocity;
            v.y = jumpVelocity;
            rb.linearVelocity = v;
            lastJumpPressTime = -10f;
            lastGroundedTime = -10f;
            SpawnPoof(new Vector3(transform.position.x, box.bounds.min.y + 0.2f, 0f));
        }

        // Pulo variável: soltar o botão corta a subida.
        if (!GameInput.JumpHeld() && rb.linearVelocity.y > 0f)
        {
            var v = rb.linearVelocity;
            v.y *= 0.5f;
            rb.linearVelocity = v;
        }

        UpdateAnimation();

        // Pisca enquanto está invulnerável.
        if (Time.time < invulnerableUntil)
            sr.enabled = Mathf.FloorToInt(Time.time * 15f) % 2 == 0;
        else
            sr.enabled = true;
    }

    void FixedUpdate()
    {
        grounded = CheckGrounded();
        if (grounded) lastGroundedTime = Time.time;
        if (dead) return;

        float input = (Time.time < controlLockedUntil || (level != null && level.IsFinished)) ? 0f : GameInput.Horizontal();
        var v = rb.linearVelocity;
        if (Time.time >= controlLockedUntil)
            v.x = Mathf.MoveTowards(v.x, input * moveSpeed, acceleration * Time.fixedDeltaTime);
        rb.linearVelocity = v;

        if (input > 0.01f) sr.flipX = false;
        else if (input < -0.01f) sr.flipX = true;
    }

    bool CheckGrounded()
    {
        Bounds b = box.bounds;
        Vector2 center = new Vector2(b.center.x, b.min.y - 0.04f);
        Vector2 size = new Vector2(b.size.x * 0.9f, 0.08f);
        var hits = Physics2D.OverlapBoxAll(center, size, 0f);
        foreach (var h in hits)
        {
            if (h == box || h.isTrigger) continue;
            return rb.linearVelocity.y <= 0.05f;
        }
        return false;
    }

    void UpdateAnimation()
    {
        if (anim == null) return;
        if (Time.time < controlLockedUntil) anim.Play("hurt");
        else if (!grounded) anim.Play("jump");
        else if (Mathf.Abs(rb.linearVelocity.x) > 0.3f) anim.Play("run");
        else anim.Play("idle");
    }

    // ---------- Inimigos ----------
    void OnTriggerEnter2D(Collider2D other) { HandleEnemy(other); }
    void OnTriggerStay2D(Collider2D other) { HandleEnemy(other); }

    void HandleEnemy(Collider2D other)
    {
        if (dead) return;
        var enemy = other.GetComponent<Enemy>();
        if (enemy == null || enemy.IsDead) return;

        bool falling = rb.linearVelocity.y < 0.5f;
        bool above = box.bounds.min.y > other.bounds.center.y;
        if (falling && above)
        {
            enemy.Stomp();
            GameState.Score += 50;
            var v = rb.linearVelocity;
            v.y = stompBounce;
            rb.linearVelocity = v;
            if (level != null) level.ShowPopup("+50", enemy.transform.position);
        }
        else
        {
            TakeDamage(Mathf.Sign(transform.position.x - other.transform.position.x));
        }
    }

    public void TakeDamage(float dir)
    {
        if (dead || Time.time < invulnerableUntil) return;
        GameState.Lives--;
        invulnerableUntil = Time.time + invulnerableTime;
        controlLockedUntil = Time.time + 0.35f;
        if (dir == 0f) dir = sr.flipX ? 1f : -1f;
        rb.linearVelocity = new Vector2(knockback.x * dir, knockback.y);
        if (GameState.Lives <= 0) StartCoroutine(Die());
    }

    public void FellInPit()
    {
        if (dead) return;
        GameState.Lives--;
        if (GameState.Lives <= 0) { StartCoroutine(Die()); return; }
        transform.position = spawnPoint;
        rb.linearVelocity = Vector2.zero;
        invulnerableUntil = Time.time + invulnerableTime;
    }

    public void SetCheckpoint(Vector3 p) { spawnPoint = p; }

    IEnumerator Die()
    {
        dead = true;
        GameState.Lives = 0;
        if (anim != null) anim.Play("hurt");
        rb.linearVelocity = new Vector2(0f, 10f);
        box.enabled = false;
        yield return new WaitForSeconds(1.5f);
        GameState.GoToEnd(false);
    }

    void SpawnPoof(Vector3 pos)
    {
        if (poofPrefab != null) Instantiate(poofPrefab, pos, Quaternion.identity);
    }
}
