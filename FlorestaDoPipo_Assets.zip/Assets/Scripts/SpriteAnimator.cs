using UnityEngine;

// Animador simples de sprites quadro a quadro.
[RequireComponent(typeof(SpriteRenderer))]
public class SpriteAnimator : MonoBehaviour
{
    [System.Serializable]
    public class Clip
    {
        public string name;
        public Sprite[] frames;
        public float fps = 8f;
        public bool loop = true;
    }

    public Clip[] clips;
    public string startClip;
    [Tooltip("Começa a animação num quadro aleatório (para os itens não ficarem sincronizados).")]
    public bool randomStart;

    SpriteRenderer sr;
    Clip current;
    float timer;
    int frame;

    public bool Finished { get; private set; }
    public string CurrentName => current != null ? current.name : "";

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        if (clips != null && clips.Length > 0)
            Play(string.IsNullOrEmpty(startClip) ? clips[0].name : startClip);
        if (randomStart && current != null && current.frames.Length > 0)
        {
            frame = Random.Range(0, current.frames.Length);
            Apply();
        }
    }

    public void Play(string clipName)
    {
        if (current != null && current.name == clipName) return;
        foreach (var c in clips)
        {
            if (c.name == clipName)
            {
                current = c;
                timer = 0f;
                frame = 0;
                Finished = false;
                Apply();
                return;
            }
        }
    }

    void Update()
    {
        if (current == null || current.frames == null || current.frames.Length == 0) return;
        timer += Time.deltaTime;
        float frameTime = 1f / Mathf.Max(0.01f, current.fps);
        while (timer >= frameTime)
        {
            timer -= frameTime;
            frame++;
            if (frame >= current.frames.Length)
            {
                if (current.loop) frame = 0;
                else { frame = current.frames.Length - 1; Finished = true; }
            }
        }
        Apply();
    }

    void Apply()
    {
        if (sr != null && current != null && current.frames.Length > 0)
            sr.sprite = current.frames[frame];
    }
}
