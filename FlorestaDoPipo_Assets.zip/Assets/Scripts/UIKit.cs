using UnityEngine;

// Estilos de interface (IMGUI) com escala proporcional à altura da tela.
public static class UIKit
{
    public static float Scale => Screen.height / 720f;

    static Texture2D panelTex, buttonTex, buttonHoverTex;

    static Texture2D Solid(Color c)
    {
        var t = new Texture2D(1, 1);
        t.SetPixel(0, 0, c);
        t.Apply();
        t.hideFlags = HideFlags.HideAndDontSave;
        return t;
    }

    public static Texture2D PanelTex => panelTex != null ? panelTex : (panelTex = Solid(new Color(0.09f, 0.08f, 0.14f, 0.82f)));
    static Texture2D ButtonTex => buttonTex != null ? buttonTex : (buttonTex = Solid(new Color(0.91f, 0.47f, 0.17f, 1f)));
    static Texture2D ButtonHoverTex => buttonHoverTex != null ? buttonHoverTex : (buttonHoverTex = Solid(new Color(1f, 0.62f, 0.3f, 1f)));

    public static GUIStyle Label(int size, Color color, TextAnchor anchor = TextAnchor.MiddleCenter, bool bold = true)
    {
        var s = new GUIStyle(GUI.skin.label);
        s.fontSize = Mathf.RoundToInt(size * Scale);
        s.normal.textColor = color;
        s.alignment = anchor;
        s.fontStyle = bold ? FontStyle.Bold : FontStyle.Normal;
        s.wordWrap = true;
        s.richText = true;
        return s;
    }

    public static GUIStyle Button(int size)
    {
        var s = new GUIStyle(GUI.skin.button);
        s.fontSize = Mathf.RoundToInt(size * Scale);
        s.fontStyle = FontStyle.Bold;
        s.normal.background = ButtonTex;
        s.hover.background = ButtonHoverTex;
        s.active.background = ButtonHoverTex;
        s.normal.textColor = Color.white;
        s.hover.textColor = Color.white;
        s.active.textColor = Color.white;
        return s;
    }

    // Texto com sombra para ler bem por cima do cenário.
    public static void ShadowLabel(Rect r, string text, GUIStyle style)
    {
        var c = style.normal.textColor;
        style.normal.textColor = new Color(0f, 0f, 0f, 0.6f);
        float o = Mathf.Max(1f, 2f * Scale);
        GUI.Label(new Rect(r.x + o, r.y + o, r.width, r.height), text, style);
        style.normal.textColor = c;
        GUI.Label(r, text, style);
    }

    public static void Panel(Rect r)
    {
        GUI.DrawTexture(r, PanelTex);
    }

    public static void DrawSprite(Rect r, Sprite s)
    {
        if (s == null) return;
        var t = s.texture;
        var tr = s.textureRect;
        GUI.DrawTextureWithTexCoords(r, t, new Rect(tr.x / t.width, tr.y / t.height, tr.width / t.width, tr.height / t.height));
    }
}
